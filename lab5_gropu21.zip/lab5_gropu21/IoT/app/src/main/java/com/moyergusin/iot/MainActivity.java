package com.moyergusin.iot;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    MyThread StartThread;
    private Handler handlerThread;
    private InputStream inputStream;
    private OutputStream outputStream;
    private Socket socket;
    private String IP_address;
    private String Context;
    private byte buffer[];
    private int temp;
    private TextView result_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result_view = findViewById(R.id.speech_view);
    }

    class MyThread extends Thread {
        public void run(){
            System.out.println("Thread starts.");
            buffer = new byte[1024];
            temp = 0;
            try{
                socket = new Socket(IP_address, 8080);
                inputStream = socket.getInputStream();
                outputStream = socket.getOutputStream();
                temp = inputStream.read(buffer);
                System.out.println(new String(buffer, 0, temp));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, new String(buffer,0,temp), Toast.LENGTH_SHORT).show();
                    }
                });
            }catch (Exception e){
                e.printStackTrace();
            }

            Looper.prepare();
            handlerThread = new Handler(){
                public void handleMessage (Message msg) {
                    System.out.println("Handler starts.");
                    byte b[] = new byte[64];
                    b[0] = (byte) msg.what;
                    if (msg.what == 2){
                        try {
                            byte s[] = Context.getBytes("utf-8");
                            for (int i = 0; i < s.length; i++) {
                                b[i + 1] = s[i];
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                    try {
                        outputStream.write(b);
                        outputStream.flush();
                        System.out.println("Successfully transmit.");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    try{
                        buffer = new byte[1024];
                        temp = 0;
                        temp = inputStream.read(buffer);
                        System.out.println(new String(buffer, 0, temp));
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, new String(buffer,0,temp), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    if (msg.what == 3) {
                        handlerThread.getLooper().quit();
                    }
                }
            };
            Looper.loop();
            try {
                socket.close();
                System.out.println("Successfully close.");
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void screen_on(View view) {
        handlerThread.obtainMessage(1, "screen_on").sendToTarget();
    }

    public void screen_off(View view) {
        handlerThread.obtainMessage(0, "screen_off").sendToTarget();
    }

    public void connect_server(View view){
        EditText editText = (EditText) findViewById(R.id.ip_address);
        IP_address = editText.getText().toString();
        StartThread = new MyThread();
        StartThread.start();
    }

    public void disconnect_server(View view){
        handlerThread.obtainMessage(3, "disconnect").sendToTarget();
    }

    public void getSpeechInput(View view) {

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 10);
        } else {
            Toast.makeText(this, "Your Device Don't Support Speech Input", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    Context = result.get(0);
                    result_view.setText(Context);
                    System.out.println(Context);
                    if (Context.equals("turn on")){
                        handlerThread.obtainMessage(1, "send_text").sendToTarget();
                    }
                    else if (Context.equals("turn off")){
                        handlerThread.obtainMessage(0, "send_text").sendToTarget();
                    }
                    else {
                        handlerThread.obtainMessage(2, "send_text").sendToTarget();
                    }
                }
                break;
        }
    }
}
