import usocket as socket
import machine
from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import time

i2c = I2C(-1, scl=Pin(5), sda=Pin(16), freq=40000)
oled = SSD1306_I2C(128, 32, i2c)
oled.invert(False)
oled.contrast(255)

init_time = (2018, 9, 26, 3, 23, 57, 40, 0)
rtc = machine.RTC()
rtc.datetime(init_time)


def do_connect(ssid, password):
    import network
    sta_if = network.WLAN(network.STA_IF)
    count = 0
    if not sta_if.isconnected():
        screen_show("Not connect.\n%d" % count)
        sta_if.active(True)
        sta_if.connect(ssid, password)
        while not sta_if.isconnected():
            pass
    return sta_if.ifconfig()[0]


def screen_show(context):
    global oled
    lines = context.split('\n')
    oled.fill(0)
    for i in range(len(lines)):
        oled.text(lines[i], 0, 10 * i)
    oled.show()


def main(IP):
    s = socket.socket()
    ai = socket.getaddrinfo(IP, 8080)
    addr = ai[0][-1]

    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(addr)
    s.listen(5)
    while True:
        screen_show('Wait:' + '\n' + str(IP))
        res = s.accept()
        client_sock = res[0]
        client_addr = res[1]

        client_sock.setblocking(0)
        client_stream = client_sock.makefile("rwb")
        client_stream.write(b'Successfully connect to ESP8266.')
        mode = 1
        while True:
            try:
                req = client_stream.recv(64)
                if int(req[0]) == 0:
                    client_stream.write(b'Screen turns off.')
                    mode = 0
                    screen_show('')
                elif int(req[0]) == 1:
                    client_stream.write(b'Screen turns on.')
                    mode = 1
                elif int(req[0]) == 2:
                    client_stream.write(b'Speech text received.')
                    mode = 2
                    req = req[1:]
                    text = req.decode('utf-8')
                    screen_show(text)
                elif int(req[0]) == 3:
                    client_stream.write(b'Disconnect.')
                    time.sleep(0.5)
                    break
            except:
                pass
            if mode == 1:
                timing = rtc.datetime()
                buf1 = '.'.join(map(str, timing[:3]))
                buf2 = ':'.join(map(str, timing[4:-1]))
                screen_show(buf1+'\n'+buf2)
        client_stream.close()
        client_sock.close()


IP = do_connect('Columbia University', '')
screen_show(IP)
main(IP)
